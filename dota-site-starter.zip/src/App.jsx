import { Link, NavLink, Route, Routes } from "react-router-dom";

const heroes = [
  { id: "invoker", name: "Invoker", role: "Маг", color: "violet" },
  { id: "juggernaut", name: "Juggernaut", role: "Керри", color: "red" },
  { id: "pudge", name: "Pudge", role: "Танк", color: "green" },
  { id: "crystal-maiden", name: "Crystal Maiden", role: "Поддержка", color: "blue" }
];

function Layout({ children }) {
  return (
    <div className="app-shell">
      <header className="header">
        <Link className="logo" to="/">
          <span className="logo-mark">D</span>
          <span>DOTA HUB</span>
        </Link>

        <nav className="nav">
          <NavLink to="/" end>Главная</NavLink>
          <NavLink to="/heroes">Герои</NavLink>
          <NavLink to="/items">Предметы</NavLink>
          <NavLink to="/guides">Гайды</NavLink>
          <NavLink to="/news">Новости</NavLink>
          <NavLink to="/about">О проекте</NavLink>
        </nav>
      </header>

      <main>{children}</main>

      <footer className="footer">
        <span>© 2026 Dota Hub</span>
        <span>Первый рабочий каркас проекта</span>
      </footer>
    </div>
  );
}

function Home() {
  return (
    <section className="container hero-section">
      <div className="hero-copy">
        <div className="eyebrow">DOTA 2 DATABASE</div>
        <h1>Твой новый<br /><span>Dota Hub</span></h1>
        <p>
          Это уже не одна страница. Перед тобой основа полноценного сайта
          с отдельными разделами и переходами между страницами.
        </p>
        <div className="actions">
          <Link className="button primary" to="/heroes">Открыть героев</Link>
          <Link className="button secondary" to="/guides">Смотреть гайды</Link>
        </div>
      </div>

      <div className="home-card">
        <div className="card-glow" />
        <div className="home-card-content">
          <span>СТАТУС ПРОЕКТА</span>
          <strong>WORKING</strong>
          <p>Маршрутизация уже работает.</p>
        </div>
      </div>
    </section>
  );
}

function Heroes() {
  return (
    <section className="container page">
      <div className="page-heading">
        <div>
          <div className="eyebrow">DATABASE</div>
          <h1>Герои</h1>
        </div>
        <p>Выбери героя, чтобы перейти на отдельную страницу.</p>
      </div>

      <div className="grid">
        {heroes.map((hero) => (
          <Link className={`hero-card ${hero.color}`} key={hero.id} to={`/heroes/${hero.id}`}>
            <div className="hero-avatar">{hero.name[0]}</div>
            <div>
              <h2>{hero.name}</h2>
              <span>{hero.role}</span>
            </div>
            <b>→</b>
          </Link>
        ))}
      </div>
    </section>
  );
}

function HeroPage({ id }) {
  const hero = heroes.find((item) => item.id === id);

  if (!hero) {
    return (
      <section className="container page">
        <h1>Герой не найден</h1>
        <Link className="button primary" to="/heroes">Вернуться к героям</Link>
      </section>
    );
  }

  return (
    <section className="container page">
      <Link className="back" to="/heroes">← Все герои</Link>
      <div className={`detail-card ${hero.color}`}>
        <div className="detail-avatar">{hero.name[0]}</div>
        <div>
          <div className="eyebrow">HERO</div>
          <h1>{hero.name}</h1>
          <p>Роль: {hero.role}</p>
          <p className="muted">
            Здесь позже появятся характеристики, способности, предметы,
            билды, таланты и другая информация.
          </p>
        </div>
      </div>
    </section>
  );
}

function Placeholder({ title, description }) {
  return (
    <section className="container page">
      <div className="placeholder">
        <div className="eyebrow">SECTION</div>
        <h1>{title}</h1>
        <p>{description}</p>
        <Link className="button primary" to="/">На главную</Link>
      </div>
    </section>
  );
}

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/heroes" element={<Heroes />} />
        <Route path="/heroes/:id" element={<HeroRoute />} />
        <Route path="/items" element={<Placeholder title="Предметы" description="Раздел предметов готов для дальнейшего наполнения." />} />
        <Route path="/guides" element={<Placeholder title="Гайды" description="Здесь будут билды и подробные руководства." />} />
        <Route path="/news" element={<Placeholder title="Новости" description="Здесь появится лента новостей." />} />
        <Route path="/about" element={<Placeholder title="О проекте" description="Информация о Dota Hub и его возможностях." />} />
        <Route path="*" element={<Placeholder title="404" description="Такой страницы пока нет." />} />
      </Routes>
    </Layout>
  );
}

import { useParams } from "react-router-dom";

function HeroRoute() {
  const { id } = useParams();
  return <HeroPage id={id} />;
}

export default App;